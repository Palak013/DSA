/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
#include <bits/stdc++.h>
using namespace std;

// check if two strings are rotation of each other

bool areRotations( string str1,string str2){
    if(str1.length()!=str2.length()){
        return false;
    }
     string temp = str1 + str1;
    return (temp.find(str2) != string::npos);
}
int main()
{
    string str1 = "AACD", str2 = "ACDA";

    // Function call
    if (areRotations(str1, str2))
        printf("Strings are rotations of each other");
    else
        printf("Strings are not rotations of each other");
    return 0;
}